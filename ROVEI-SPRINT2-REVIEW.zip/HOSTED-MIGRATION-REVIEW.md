# Hosted migration approval package

No hosted migration has been executed. Intended candidate: the healthy connected **Rovei-3-** project, reference `errzsgncbygxwwmwndha`. Its association with the running Codespace must be confirmed using the nonsecret project reference before approval or writes.

## Exact review sequence

The five SQL files below are copied unchanged from the reviewed source. The first four already exist in the installed Sprint 1 tree; only the fifth is new Sprint 2 source. Review each hash and its diff before authorizing application.

| Migration | SHA-256 |
|---|---|
| `202610110001_subscription_access.sql` | `233d0b3f1447f282b6fa48117e1bb90367e1816da1c17dd5d7e6746c83385b82` |
| `202610120001_support_requests.sql` | `b84c33de0bf483a561268123ae4edf53586b723511ca602361858981c5a3b340` |
| `20261014155715_launch_billing_hardening.sql` | `863a33f89573459fd793efbba78bc431da415d2e5ff728ece7b19d85adac78c2` |
| `20261014160018_atomic_studio_and_pack_saves.sql` | `57050c46d958cc49c9c19ba991a0ac145516b439a216dd793a11747460a086b2` |
| `20261014182409_persistent_studio_workflows.sql` | `e696d941e5a4f53da4a2f5c9480922aa6d0a27869e830cd6e80acf101920b5a1` |

## Read-only hosted evidence

Recorded versions remain `202610030001`, `202610030002`, `202610040001`, `202610060001`, `202610130001`. The paid-access function and atomic Studio/Beauty Pack RPCs are absent; intended paid-access policy count is zero. The private photo bucket exists. Storage object policies are empty, so browsers must not be granted object access as a workaround: new uploads/signing use server authorization plus the service role. Service-role Storage schema usage and bucket SELECT grants are present.

The support table's eleven columns, nullable flags, defaults, constraints, indexes, RLS, self-only SELECT/INSERT policies and role grants match the existing source migration. Anonymous SELECT and authenticated UPDATE/DELETE are denied. Reapplying this idempotent support migration to an existing fixture table preserved its records. This is a schema comparison and rehearsal, not a hosted migration-history repair.

The connected project still has overly broad helper execution/mutable search-path findings until the reviewed hardening migration is applied. Leaked-password protection remains a hosted configuration item. No customer rows, accounts, notes, tokens, photos or private environment files were queried.

## Rehearsal and change behavior

All source migrations, including this sequence, executed in disposable PGlite PostgreSQL with synthetic Auth/Storage catalogs. Tests exercised paid/unpaid access, two-tenant isolation, browser RPC denial, server scheduling checks, rollback on conflicts, photo path/cap/attachment checks, idempotent intake and visit completion, record retention and database close/reopen. The readiness RPC runs under the service role and detects unsafe browser metadata grants. These tests do not establish hosted Supabase Auth/Storage behavior or multi-process concurrent booking safety.

The new migration adds tables/columns, indexes, functions, grants and a scheduling trigger. It does not delete, backfill or rewrite existing customer records. Existing conflicting bookings remain for owner review. Future inserts/reschedules/reactivations enforce working hours, active services, duration and buffer under a per-studio transaction lock. Repeating the new migration is not supported; apply it once through the migration mechanism.

## Approval boundary

Approve only after confirming the target and a usable private backup/recovery route. Re-read metadata immediately before application, stop on new differences, and retain the source SQL and actual recorded migration versions. The Supabase connector chooses its migration version; if it differs from a local filename, reconcile the history explicitly in a reviewed follow-up rather than silently pretending the versions match. Do not mark legacy migrations applied without matching schema evidence. Use a version-preserving CLI workflow when securely available and approved; never paste database passwords into chat.

This approval covers no production deployment, live billing, refund, customer-data deletion, notification-provider change or automatic Git merge. Any synthetic hosted accounts/records or Sandbox subscription cancellation need separately scoped test authorization. After application, repeat hosted tests with approved disposable tenants before launch sign-off.
