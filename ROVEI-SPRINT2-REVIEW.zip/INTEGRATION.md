# Apply only Sprint 2 to the already installed Sprint 1 tree

This is an incremental 39-file review patch. It starts from the exact safe archive plus the previously installed Sprint 1 changeset, verified against all 37 Sprint 1 output hashes. GitHub `main` was not substituted, and the original working-branch GitHub commit is not the patch preimage. Your original Codespace was not accessed or changed during this session.

Keep the original Codespace on `frontend/exact-locked-shell`. Create a separate private review copy first, preserving its current uncommitted and untracked source. Exclude dependencies, build outputs, environment files and existing private backups from any shared export. Keep private configuration local; never upload keys or environment files. Install dependencies in the review copy with `npm ci`.

Extract this ZIP outside the repository. Check the original or review source before applying:

```bash
python3 /absolute/path/to/extracted/apply-sprint2.py /workspaces/Rovei-3-
```

Prefer applying to a separate review copy after that check. Substitute its actual absolute directory:

```bash
python3 /absolute/path/to/extracted/apply-sprint2.py /absolute/path/to/review-copy --apply
```

The helper checks the installed Sprint 1 baseline, all protected hashes, every changed file's preimage and `git apply --check`. It stops on any difference and changes nothing on a failed preflight. On application it creates a private local backup of modified and nonignored untracked source, including unrelated changes, then verifies every resulting hash. A second run recognizes the complete Sprint 2 output and does not reapply it. No reset, branch switch, commit, push, merge, migration or deployment occurs.

Do not use `--3way`, force an application, overwrite differing files or apply Sprint 1 again. A mismatch requires a fresh safe source snapshot including the new differences. Do not delete or discard them to make the installer pass. The checks were rehearsed on a fresh pinned-baseline worktree, including apply-once, already-applied and changed-preimage cases.

Run in the review copy:

```bash
npm test
npm run typecheck
npm run lint
npm run build
NODE_ENV=production npm run test:routes
npm run test:e2e
```

Expected local suite: 95 tests. ESLint retains nine existing warnings and zero errors. The eight Playwright tests use explicit fixtures and require an installed working browser. They do not prove provider billing or hosted persistence. Desktop/mobile checkout screenshots are captured into Playwright's output directory when those tests run.

A diagnostic build passed here with a QA-only process-memory compatibility preload, outside the source and omitted from this patch. The standard build was blocked here by `uv_resident_set_memory` ENOENT. Your Sprint 1 standard build confirmation is preserved; run a fresh standard Sprint 2 build in Codespaces before sign-off. Never add the QA preload to Rovei or production.

This source requires the coordinated database migrations. **Do not run it against the hosted project until the reviewed migration sequence in `HOSTED-MIGRATION-REVIEW.md` is explicitly approved and applied.** The new restoration path expects `studio_intake_links`, and intake/visits/photos/health depend on new RPCs and columns. The original Codespace remains available while approval and rehearsal are completed.

The standalone report describes the remaining launch blockers. No production or live billing switch is included. See `docs/LAUNCH_RUNBOOK.md` in the patch for HTTPS, private configuration, SMTP, monitoring, backup/recovery and genuine Sandbox evidence requirements.
