#!/usr/bin/env python3
"""Verify the installed Sprint 1 source, preserve local changes, apply Sprint 2 once."""
import argparse,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('repository',type=Path)
parser.add_argument('--apply',action='store_true')
args=parser.parse_args();root=args.repository.resolve();artifact=Path(__file__).resolve().parent
if not (root/'.git').exists():sys.exit('STOP: target must be an existing Git checkout or worktree.')
manifest=json.loads((artifact/'patch-manifest.json').read_text())
baseline=json.loads((artifact/'sprint1-baseline.json').read_text())
protected=json.loads((artifact/'design-protection.json').read_text())
def target(name):
 relative=Path(name)
 if relative.is_absolute() or '..' in relative.parts:sys.exit('STOP: unsafe manifest path.')
 path=root/relative
 if path.is_symlink() or not path.resolve().is_relative_to(root):sys.exit('STOP: symlink or escaping path: '+name)
 return path
def digest(name):
 path=target(name)
 if path.exists() and not path.is_file():sys.exit('STOP: expected a file: '+name)
 return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
actual={name:digest(name) for name in manifest}
already=all(actual[name]==row['after_sha256'] for name,row in manifest.items())
errors=[]
for name,expected in baseline.items():
 if already and name in manifest:expected=manifest[name]['after_sha256']
 if digest(name)!=expected:errors.append(name+' differs from the installed Sprint 1 source')
for name,expected in protected.items():
 if digest(name)!=expected:errors.append(name+' differs from the protected design baseline')
if not already:
 for name,row in manifest.items():
  if actual[name]!=row['before_sha256']:errors.append(name+' has an unexpected preimage or already exists')
if errors:
 print('STOP: no files changed. Preserve these differences and obtain a fresh source snapshot:')
 for error in sorted(set(errors)):print(error)
 sys.exit(1)
if already:print('PASS: Sprint 2 is already applied and all output/design hashes match. No patch reapplied.');sys.exit(0)
patch=artifact/'rovei-sprint2.patch'
source=json.loads((artifact/'baseline-source.json').read_text())
if hashlib.sha256(patch.read_bytes()).hexdigest()!=source['patch_sha256']:sys.exit('STOP: patch checksum differs.')
check=subprocess.run(['git','apply','--check',str(patch)],cwd=root)
if check.returncode:sys.exit(check.returncode)
print(f'PASS: installed Sprint 1 baseline, protected files and all {len(manifest)} Sprint 2 preimages match.')
if not args.apply:print('Check only: no changes applied.');sys.exit(0)
# Backup every changed/untracked nonignored source file, including unrelated work.
# Ignored environment files, dependencies and existing private backups stay untouched.
backup=Path(tempfile.mkdtemp(prefix='rovei-sprint2-private-backup-',dir=root.parent));os.chmod(backup,0o700)
paths=set()
for command in [['git','diff','--name-only','HEAD','-z'],['git','ls-files','--others','--exclude-standard','-z']]:
 paths.update(name.decode() for name in subprocess.check_output(command,cwd=root).split(b'\0') if name)
for name in paths:
 path=target(name)
 if path.is_file():
  saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True,mode=0o700);saved.write_bytes(path.read_bytes());os.chmod(saved,0o600)
status=backup/'git-status.bin';status.write_bytes(subprocess.check_output(['git','status','--porcelain','-z'],cwd=root));os.chmod(status,0o600)
result=subprocess.run(['git','apply',str(patch)],cwd=root)
if result.returncode:sys.exit(result.returncode)
for name,row in manifest.items():
 if digest(name)!=row['after_sha256']:sys.exit('STOP: applied-file verification failed: '+name)
for name,expected in protected.items():
 if digest(name)!=expected:sys.exit('STOP: protected-file verification failed: '+name)
print('PASS: patch applied once; all output and protected hashes verified.')
print('Private local backup: '+str(backup))
print('No commit, push, branch switch, merge, hosted migration, deployment or provider action performed.')
