begin;

-- Apply the missing subscription-access migration before this migration.
create or replace function public.is_studio_subscription_active(target_studio_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select auth.uid() is not null
    and public.is_studio_member(target_studio_id)
    and exists (select 1 from public.subscriptions s where s.studio_id = target_studio_id
      and s.status in ('active', 'trialing') and s.current_period_end > pg_catalog.now());
$$;
revoke all on function public.is_studio_subscription_active(uuid) from public, anon;
grant execute on function public.is_studio_subscription_active(uuid) to authenticated;

alter function public.set_updated_at() set search_path = '';
revoke all on function public.handle_new_user() from public, anon, authenticated;
revoke all on function public.add_studio_owner_membership() from public, anon, authenticated;
revoke all on function public.is_studio_member(uuid) from public, anon;
revoke all on function public.is_studio_owner(uuid) from public, anon;
grant execute on function public.is_studio_member(uuid) to authenticated;
grant execute on function public.is_studio_owner(uuid) to authenticated;
-- Deliberately no browser policies for Paddle's internal reservation/event tables.
grant select, insert, update, delete on public.paddle_webhook_events, public.paddle_checkout_attempts to service_role;

create or replace function public.apply_paddle_subscription_event(
  p_event_id text,
  p_event_type text,
  p_occurred_at timestamptz,
  p_studio_id uuid,
  p_user_id uuid,
  p_subscription_id text,
  p_customer_id text,
  p_price_id text,
  p_status text,
  p_current_period_start timestamptz,
  p_current_period_end timestamptz,
  p_scheduled_cancel_at timestamptz
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  inserted_event_count integer;
  existing_subscription public.subscriptions%rowtype;
begin
  if p_event_type not in (
    'subscription.created',
    'subscription.updated',
    'subscription.canceled',
    'subscription.activated',
    'subscription.trialing',
    'subscription.past_due',
    'subscription.paused',
    'subscription.resumed'
  ) then
    raise exception 'Unsupported Paddle event type';
  end if;

  if p_status not in (
    'active',
    'trialing',
    'past_due',
    'paused',
    'cancelled'
  ) then
    raise exception 'Unsupported Paddle subscription status';
  end if;

  if not exists (
    select 1
    from public.studio_members as member
    join public.studios as studio
      on studio.id = member.studio_id
    where member.studio_id = p_studio_id
      and member.user_id = p_user_id
      and member.role = 'owner'
      and studio.owner_user_id = p_user_id
  ) then
    raise exception 'Paddle account does not match a Studio owner';
  end if;

  -- Serialize even when the Studio has no subscription row yet.
  perform 1 from public.studios where id = p_studio_id for update;

  insert into public.paddle_webhook_events (
    event_id,
    event_type,
    occurred_at
  )
  values (
    p_event_id,
    p_event_type,
    p_occurred_at
  )
  on conflict (event_id) do nothing;

  get diagnostics inserted_event_count = row_count;
  if inserted_event_count = 0 then
    return false;
  end if;

  select *
  into existing_subscription
  from public.subscriptions
  where studio_id = p_studio_id
  for update;

  if found then
    -- A terminated Paddle subscription can never be resurrected by a late event.
    if existing_subscription.provider_subscription_id = p_subscription_id
       and existing_subscription.status = 'cancelled'
       and p_status <> 'cancelled' then
      return false;
    end if;
    if existing_subscription.provider_subscription_id is not null
       and existing_subscription.provider_subscription_id <> p_subscription_id
       and existing_subscription.status <> 'cancelled' then
      raise exception 'Studio already has a different Paddle subscription';
    end if;

    if existing_subscription.last_event_at is not null
       and (
         p_occurred_at < existing_subscription.last_event_at
         or (
           p_occurred_at = existing_subscription.last_event_at
           and existing_subscription.last_event_id is not null
           and p_event_id collate "C" <= existing_subscription.last_event_id collate "C"
         )
       ) then
      return false;
    end if;
  end if;

  insert into public.subscriptions (
    studio_id,
    provider,
    provider_customer_id,
    provider_subscription_id,
    price_id,
    status,
    current_period_start,
    current_period_end,
    scheduled_cancel_at,
    last_event_at,
    last_event_id
  )
  values (
    p_studio_id,
    'paddle',
    p_customer_id,
    p_subscription_id,
    p_price_id,
    p_status,
    p_current_period_start,
    p_current_period_end,
    p_scheduled_cancel_at,
    p_occurred_at,
    p_event_id
  )
  on conflict (studio_id) do update
  set
    provider_customer_id = excluded.provider_customer_id,
    provider_subscription_id = excluded.provider_subscription_id,
    price_id = excluded.price_id,
    status = excluded.status,
    current_period_start = excluded.current_period_start,
    current_period_end = excluded.current_period_end,
    scheduled_cancel_at = excluded.scheduled_cancel_at,
    last_event_at = excluded.last_event_at,
    last_event_id = excluded.last_event_id
  where (
      public.subscriptions.provider_subscription_id is null
      or public.subscriptions.provider_subscription_id = excluded.provider_subscription_id
      or public.subscriptions.status = 'cancelled'
    )
    and (
      public.subscriptions.last_event_at is null
      or excluded.last_event_at > public.subscriptions.last_event_at
      or (
        excluded.last_event_at = public.subscriptions.last_event_at
        and (
          public.subscriptions.last_event_id is null
          or excluded.last_event_id collate "C" > public.subscriptions.last_event_id collate "C"
        )
      )
    );

  get diagnostics inserted_event_count = row_count;
  if inserted_event_count = 0 then
    return false;
  end if;

  if p_status <> 'cancelled' then
    delete from public.paddle_checkout_attempts
    where studio_id = p_studio_id
      and (
        transaction_id is not null
        or lease_expires_at <= pg_catalog.now()
      );
  end if;

  return true;
end;
$$;


commit;
