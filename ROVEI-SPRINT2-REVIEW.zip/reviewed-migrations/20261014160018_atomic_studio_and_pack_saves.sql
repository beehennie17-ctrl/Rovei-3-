begin;

-- These invoker functions retain the caller's RLS and run each save atomically.
create or replace function public.save_studio_configuration(
  p_studio_id uuid, p_name text, p_timezone text, p_theme text,
  p_primary text, p_custom_primary text, p_modules jsonb, p_services text[],
  p_availability jsonb default null, p_notifications jsonb default null
) returns boolean language plpgsql security invoker set search_path = '' as $$
begin
  if not public.is_studio_owner(p_studio_id) or not public.is_studio_subscription_active(p_studio_id) then
    raise exception 'Active Studio owner required';
  end if;
  if p_name is null or p_services is null or p_modules is null or p_theme is null
     or p_primary is null or p_custom_primary is null or p_timezone is null
     or p_theme not in ('blush','noir','pearl','wine','mocha','sage','lilac','custom')
     or p_primary !~ '^#[0-9A-Fa-f]{6}$' or p_custom_primary !~ '^#[0-9A-Fa-f]{6}$'
     or not exists(select 1 from pg_catalog.pg_timezone_names where name=p_timezone)
     or jsonb_typeof(p_modules) <> 'array' or jsonb_array_length(p_modules) not between 1 and 6
     or exists(select 1 from jsonb_array_elements_text(p_modules) m where m not in ('consultation','preferences','inspiration','consent','prep','current-photos'))
     or char_length(trim(p_name)) not between 2 and 60 or cardinality(p_services) not between 1 and 6
     or not p_services <@ array['lashes','brows','nails','makeup','facials','other']::text[] then
    raise exception 'Invalid Studio configuration';
  end if;
  update public.studios set name=trim(p_name), timezone=p_timezone where id=p_studio_id;
  if not found then raise exception 'Studio unavailable'; end if;
  insert into public.studio_settings(studio_id,primary_colour,theme_name,theme_config,experience_modules,availability)
  values(p_studio_id,p_primary,p_theme,jsonb_build_object('customPrimary',p_custom_primary) ||
    case when p_notifications is null then '{}'::jsonb else jsonb_build_object('notifications',p_notifications) end,
    p_modules,coalesce(p_availability,'{}'::jsonb))
  on conflict(studio_id) do update set primary_colour=excluded.primary_colour,theme_name=excluded.theme_name,
    theme_config=public.studio_settings.theme_config || excluded.theme_config,
    experience_modules=excluded.experience_modules,
    availability=coalesce(p_availability,public.studio_settings.availability);
  update public.services set active=(category=any(p_services)) where studio_id=p_studio_id
    and category=any(array['lashes','brows','nails','makeup','facials','other']::text[]);
  insert into public.services(studio_id,name,category,active,sort_order)
  select p_studio_id, initcap(category), category,true,ordinality::integer
  from unnest(p_services) with ordinality as selected(category,ordinality)
  where not exists(select 1 from public.services s where s.studio_id=p_studio_id and s.category=selected.category);
  return true;
end;
$$;
revoke all on function public.save_studio_configuration(uuid,text,text,text,text,text,jsonb,text[],jsonb,jsonb) from public,anon;
grant execute on function public.save_studio_configuration(uuid,text,text,text,text,text,jsonb,text[],jsonb,jsonb) to authenticated;

create or replace function public.save_beauty_pack(
  p_studio_id uuid, p_pack_id uuid, p_name text, p_service text, p_modules text[]
) returns jsonb language plpgsql security invoker set search_path = '' as $$
declare v_id uuid;
begin
  if not public.is_studio_subscription_active(p_studio_id) then raise exception 'Active Studio member required'; end if;
  if p_name is null or p_service is null or p_modules is null or char_length(trim(p_name)) not between 2 and 60 or cardinality(p_modules) not between 1 and 6
    or p_service not in ('lashes','brows','nails','makeup','facials','other')
    or not p_modules <@ array['consultation','preferences','inspiration','consent','prep','current-photos']::text[]
    or cardinality(p_modules) <> (select count(distinct m) from unnest(p_modules) m) then
    raise exception 'Invalid Beauty Pack';
  end if;
  if p_pack_id is null then
    insert into public.beauty_packs(studio_id,name,service_category,active) values(p_studio_id,trim(p_name),p_service,true) returning id into v_id;
  else
    update public.beauty_packs set name=trim(p_name),service_category=p_service where id=p_pack_id and studio_id=p_studio_id returning id into v_id;
    if v_id is null then raise exception 'Beauty Pack unavailable'; end if;
    delete from public.beauty_pack_modules where beauty_pack_id=v_id and studio_id=p_studio_id;
  end if;
  insert into public.beauty_pack_modules(studio_id,beauty_pack_id,module_type,sort_order,config)
  select p_studio_id,v_id,module,ordinality::integer-1,'{}'::jsonb from unnest(p_modules) with ordinality as selected(module,ordinality);
  return (select jsonb_build_object('id',id,'name',name,'service',service_category,'modules',to_jsonb(p_modules),
    'createdAt',created_at,'updatedAt',updated_at) from public.beauty_packs where id=v_id and studio_id=p_studio_id);
end;
$$;
revoke all on function public.save_beauty_pack(uuid,uuid,text,text,text[]) from public,anon;
grant execute on function public.save_beauty_pack(uuid,uuid,text,text,text[]) to authenticated;

commit;
