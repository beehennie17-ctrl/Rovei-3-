begin;

create schema if not exists rovei_private;
revoke all on schema rovei_private from public, anon, authenticated;

-- Public form IDs disclose only a Studio's booking form, never existing records.
create table public.studio_intake_links (
  id uuid primary key default gen_random_uuid(),
  studio_id uuid not null unique references public.studios(id) on delete cascade,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.studio_intake_links enable row level security;
revoke all on public.studio_intake_links from public, anon, authenticated;
grant select, insert on public.studio_intake_links to authenticated;
grant all on public.studio_intake_links to service_role;
create policy intake_link_owner_select on public.studio_intake_links for select to authenticated
using(public.is_studio_owner(studio_id) and public.is_studio_subscription_active(studio_id));
create policy intake_link_owner_insert on public.studio_intake_links for insert to authenticated
with check(public.is_studio_owner(studio_id) and public.is_studio_subscription_active(studio_id));

create table public.intake_sessions (
  id uuid primary key default gen_random_uuid(),
  link_id uuid not null references public.studio_intake_links(id) on delete cascade,
  studio_id uuid not null references public.studios(id) on delete cascade,
  request_id uuid not null,
  secret_hash text not null check(secret_hash ~ '^[0-9a-f]{64}$'),
  expires_at timestamptz not null default now()+interval '2 hours',
  completed_at timestamptz,
  client_id uuid,
  appointment_id uuid,
  submission_hash text,
  created_at timestamptz not null default now(),
  unique(link_id,request_id),
  unique(secret_hash),
  foreign key(client_id,studio_id) references public.clients(id,studio_id),
  foreign key(appointment_id,studio_id) references public.appointments(id,studio_id)
);
alter table public.intake_sessions enable row level security;
revoke all on public.intake_sessions from public, anon, authenticated;
grant all on public.intake_sessions to service_role;
create index intake_sessions_link_created_idx on public.intake_sessions(link_id,created_at);

alter table public.appointments add column duration_minutes integer check(duration_minutes between 5 and 1440);
alter table public.file_assets add column intake_session_id uuid references public.intake_sessions(id);
alter table public.file_assets add column upload_request_id uuid;
alter table public.visit_memories add column request_id uuid;
create unique index visit_request_idempotency_idx on public.visit_memories(studio_id,request_id) where request_id is not null;
create unique index visit_appointment_completion_idx on public.visit_memories(appointment_id) where appointment_id is not null and request_id is not null;
create index staged_photo_request_idx on public.file_assets(studio_id,upload_request_id);
create index staged_photo_session_idx on public.file_assets(intake_session_id,kind);
-- Browser-supplied metadata must never cause an admin signer to sign arbitrary paths.
revoke insert,update,delete on public.file_assets from authenticated;

create or replace function public.ensure_studio_intake_link(p_studio_id uuid)
returns uuid language plpgsql security invoker set search_path='' as $$
declare result uuid;
begin
  if not public.is_studio_owner(p_studio_id) or not public.is_studio_subscription_active(p_studio_id) then raise exception 'Active Studio owner required'; end if;
  insert into public.studio_intake_links(studio_id) values(p_studio_id) on conflict(studio_id) do nothing;
  select id into result from public.studio_intake_links where studio_id=p_studio_id and revoked_at is null;
  if result is null then raise exception 'Intake link unavailable'; end if;
  return result;
end;
$$;
revoke all on function public.ensure_studio_intake_link(uuid) from public,anon;
grant execute on function public.ensure_studio_intake_link(uuid) to authenticated;

-- Every appointment writer, including direct REST writes, follows this lock/check.
-- Existing rows are not rewritten; existing overlaps need owner review separately.
create or replace function rovei_private.enforce_appointment_schedule()
returns trigger language plpgsql security invoker set search_path='' as $$
declare duration integer; buffer_minutes integer; available jsonb; studio_timezone text;
  local_start timestamp; local_end timestamp; start_time time; end_time time; day_name text;
begin
  if new.status <> 'scheduled' then return new; end if;
  if tg_op='UPDATE' and new.starts_at=old.starts_at and new.service_id is not distinct from old.service_id and old.status='scheduled' then new.duration_minutes:=old.duration_minutes; new.timezone:=old.timezone; return new; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(new.studio_id::text,0));
  if not exists(select 1 from public.subscriptions where studio_id=new.studio_id and status in ('active','trialing') and current_period_end>now()) then raise exception 'Active subscription required'; end if;
  select coalesce(s.duration_minutes,30) into duration from public.services s where s.id=new.service_id and s.studio_id=new.studio_id and s.active;
  if duration is null then raise exception 'Active service required'; end if;
  select coalesce(ss.availability,'{}'::jsonb),st.timezone into available,studio_timezone from public.studios st left join public.studio_settings ss on ss.studio_id=st.id where st.id=new.studio_id;
  new.duration_minutes:=duration;
  new.timezone:=studio_timezone;
  local_start:=new.starts_at at time zone studio_timezone;
  local_end:=(new.starts_at+make_interval(mins=>duration)) at time zone studio_timezone;
  day_name:=(array['sun','mon','tue','wed','thu','fri','sat'])[extract(dow from local_start)::integer+1];
  start_time:=coalesce(nullif(available->>'start',''),'09:00')::time;
  end_time:=coalesce(nullif(available->>'end',''),'17:00')::time;
  buffer_minutes:=coalesce(nullif(available->>'buffer',''),'15')::integer;
  if new.starts_at<=now() or new.starts_at>now()+interval '365 days' or local_start::date<>local_end::date or local_start::time<start_time or local_end::time>end_time
    or extract(second from local_start)<>0 or mod(extract(epoch from (local_start::time-start_time))::integer,1800)<>0
    or not coalesce((available->'days'->>day_name)::boolean,day_name=any(array['mon','tue','wed','thu','fri'])) then raise exception 'Appointment is outside Studio availability'; end if;
  if exists(select 1 from public.appointments a left join public.services s on s.id=a.service_id and s.studio_id=a.studio_id
    where a.studio_id=new.studio_id and a.id<>new.id and a.status='scheduled'
      and tstzrange(a.starts_at,a.starts_at+make_interval(mins=>coalesce(a.duration_minutes,s.duration_minutes,30)+buffer_minutes),'[)')
          && tstzrange(new.starts_at,new.starts_at+make_interval(mins=>duration+buffer_minutes),'[)')) then raise exception 'Appointment time is no longer available'; end if;
  return new;
end;
$$;
revoke all on function rovei_private.enforce_appointment_schedule() from public,anon,authenticated;
create trigger enforce_appointment_schedule before insert or update of starts_at,service_id,status,duration_minutes,timezone on public.appointments
for each row execute function rovei_private.enforce_appointment_schedule();

create or replace function public.start_intake_session(p_link_id uuid,p_request_id uuid,p_secret_hash text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare link public.studio_intake_links%rowtype; session public.intake_sessions%rowtype;
begin
  select * into link from public.studio_intake_links where id=p_link_id and revoked_at is null for update;
  if not found or not exists(select 1 from public.subscriptions where studio_id=link.studio_id and status in ('active','trialing') and current_period_end>now()) then raise exception 'Intake link unavailable'; end if;
  select * into session from public.intake_sessions where link_id=p_link_id and request_id=p_request_id;
  if found then
    if session.secret_hash<>p_secret_hash then raise exception 'Submission session already reserved'; end if;
    return jsonb_build_object('id',session.id,'completed',session.completed_at is not null);
  end if;
  if (select count(*) from public.intake_sessions where link_id=p_link_id and created_at>now()-interval '1 minute')>=5
     or (select count(*) from public.intake_sessions where link_id=p_link_id and created_at>now()-interval '1 hour')>=60 then raise exception 'Intake rate limit reached'; end if;
  insert into public.intake_sessions(link_id,studio_id,request_id,secret_hash) values(p_link_id,link.studio_id,p_request_id,p_secret_hash) returning * into session;
  return jsonb_build_object('id',session.id,'completed',false);
end;
$$;
revoke all on function public.start_intake_session(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.start_intake_session(uuid,uuid,text) to service_role;

create or replace function public.submit_reusable_intake(
  p_link_id uuid,p_secret_hash text,p_first_name text,p_last_name text,p_service text,
  p_starts_at timestamptz,p_answers jsonb,p_submission_hash text,p_photo_ids uuid[]
) returns jsonb language plpgsql security invoker set search_path='' as $$
declare session public.intake_sessions%rowtype; service uuid; pack uuid; modules jsonb;
  client uuid; appointment uuid; experience uuid; module text;
begin
  select * into session from public.intake_sessions where link_id=p_link_id and secret_hash=p_secret_hash for update;
  if not found then raise exception 'Intake session unavailable'; end if;
  if session.completed_at is not null then
    if session.submission_hash is distinct from p_submission_hash then raise exception 'Completed submission cannot be changed'; end if;
    return jsonb_build_object('clientId',session.client_id,'appointmentId',session.appointment_id,'completed',true);
  end if;
  if session.expires_at<=now() or not exists(select 1 from public.studio_intake_links where id=p_link_id and revoked_at is null)
     or not exists(select 1 from public.subscriptions where studio_id=session.studio_id and status in ('active','trialing') and current_period_end>now()) then raise exception 'Intake session unavailable'; end if;
  if char_length(trim(p_first_name)) not between 1 and 50 or char_length(trim(p_last_name)) not between 1 and 50 or p_first_name is null or p_last_name is null or p_answers is null or jsonb_typeof(p_answers)<>'object' or p_starts_at is null or p_submission_hash is null or p_submission_hash !~ '^[0-9a-f]{64}$' or p_photo_ids is null or cardinality(p_photo_ids)>5 then raise exception 'Invalid client details'; end if;
  select id into service from public.services where studio_id=session.studio_id and category=p_service and active order by sort_order,id limit 1;
  if service is null then raise exception 'Active service required'; end if;
  select id into pack from public.beauty_packs where studio_id=session.studio_id and service_category=p_service and active order by created_at desc,id desc limit 1;
  if pack is not null then select coalesce(jsonb_agg(module_type order by sort_order),'[]') into modules from public.beauty_pack_modules where studio_id=session.studio_id and beauty_pack_id=pack;
  else select experience_modules into modules from public.studio_settings where studio_id=session.studio_id; end if;
  if modules is null or jsonb_array_length(modules)=0 then raise exception 'Intake modules unavailable'; end if;
  for module in select jsonb_array_elements_text(modules) loop
    if module='consultation' and char_length(trim(coalesce(p_answers->>'consultation',''))) not between 1 and 500 then raise exception 'Consultation is required'; end if;
    if module='preferences' and (coalesce(p_answers->>'finish','') not in ('natural','soft','defined','glam','not-sure') or coalesce(p_answers->>'feel','') not in ('quiet','chatty','no-preference')) then raise exception 'Preferences are required'; end if;
    if module in ('consent','prep') and coalesce(p_answers->>module,'false')<>'true' then raise exception 'Acknowledgement is required'; end if;
  end loop;
  if cardinality(p_photo_ids)<>(select count(*) from public.file_assets where id=any(p_photo_ids) and intake_session_id=session.id and studio_id=session.studio_id and client_id is null and kind in ('inspiration','current')) then raise exception 'Invalid intake photo association'; end if;
  insert into public.clients(studio_id,first_name,last_name) values(session.studio_id,trim(p_first_name),trim(p_last_name)) returning id into client;
  insert into public.appointments(studio_id,client_id,service_id,starts_at,status,readiness_status) values(session.studio_id,client,service,p_starts_at,'scheduled','ready') returning id into appointment;
  insert into public.client_experiences(studio_id,client_id,appointment_id,beauty_pack_id,status,experience_modules,current_step,completed_at)
  values(session.studio_id,client,appointment,pack,'completed',modules,jsonb_array_length(modules),now()) returning id into experience;
  for module in select jsonb_array_elements_text(modules) loop
    insert into public.client_experience_responses(studio_id,client_experience_id,module_type,payload)
    values(session.studio_id,experience,module,case module
      when 'consultation' then jsonb_build_object('goal',p_answers->>'consultation')
      when 'preferences' then jsonb_build_object('finish',p_answers->>'finish','appointmentFeel',p_answers->>'feel')
      when 'consent' then jsonb_build_object('acknowledged',true)
      when 'prep' then jsonb_build_object('acknowledged',true)
      else jsonb_build_object('skipped',not exists(select 1 from public.file_assets where id=any(p_photo_ids) and intake_session_id=session.id and kind=case module when 'current-photos' then 'current' else module end)) end);
  end loop;
  if exists(select 1 from public.file_assets where id=any(p_photo_ids) and intake_session_id=session.id and not (modules ? case kind when 'current' then 'current-photos' else kind end)) then raise exception 'Photo module is not enabled'; end if;
  update public.file_assets set client_id=client,client_experience_id=experience where id=any(p_photo_ids) and intake_session_id=session.id and studio_id=session.studio_id;
  update public.intake_sessions set completed_at=now(),client_id=client,appointment_id=appointment,submission_hash=p_submission_hash where id=session.id;
  return jsonb_build_object('clientId',client,'appointmentId',appointment,'completed',true);
end;
$$;
revoke all on function public.submit_reusable_intake(uuid,text,text,text,text,timestamptz,jsonb,text,uuid[]) from public,anon,authenticated;
grant execute on function public.submit_reusable_intake(uuid,text,text,text,text,timestamptz,jsonb,text,uuid[]) to service_role;

create or replace function public.complete_studio_visit(p_studio_id uuid,p_user_id uuid,p_request_id uuid,p_client_id uuid,p_appointment_id uuid,p_summary text,p_photo_ids uuid[])
returns jsonb language plpgsql security invoker set search_path='' as $$
declare prior public.visit_memories%rowtype; visit uuid;
begin
  if not exists(select 1 from public.studio_members where studio_id=p_studio_id and user_id=p_user_id)
    or not exists(select 1 from public.subscriptions where studio_id=p_studio_id and status in ('active','trialing') and current_period_end>now()) then raise exception 'Active Studio member required'; end if;
  perform 1 from public.appointments where id=p_appointment_id and studio_id=p_studio_id and client_id=p_client_id and status<>'cancelled' for update;
  if not found then raise exception 'Appointment unavailable'; end if;
  select * into prior from public.visit_memories where studio_id=p_studio_id and request_id=p_request_id;
  if found then
    if prior.client_id<>p_client_id or prior.appointment_id<>p_appointment_id or prior.summary is distinct from trim(p_summary) or p_photo_ids is null
      or cardinality(p_photo_ids)<>(select count(*) from public.file_assets where visit_memory_id=prior.id)
      or exists(select 1 from public.file_assets where visit_memory_id=prior.id and not(id=any(p_photo_ids))) then raise exception 'Visit request conflict'; end if;
    return jsonb_build_object('id',prior.id,'clientId',prior.client_id,'summary',prior.summary,'createdAt',prior.created_at);
  end if;
  if exists(select 1 from public.visit_memories where appointment_id=p_appointment_id and request_id is not null) then raise exception 'Appointment already completed'; end if;
  if p_summary is null or char_length(trim(p_summary)) not between 1 and 4000 or p_photo_ids is null or cardinality(p_photo_ids)>10 or p_request_id is null then raise exception 'Invalid visit'; end if;
  if cardinality(p_photo_ids)<>(select count(*) from public.file_assets where id=any(p_photo_ids) and studio_id=p_studio_id and client_id=p_client_id and upload_request_id=p_request_id and visit_memory_id is null and kind in ('before','after')) then raise exception 'Invalid visit photo association'; end if;
  insert into public.visit_memories(studio_id,client_id,appointment_id,summary,created_by,request_id) values(p_studio_id,p_client_id,p_appointment_id,trim(p_summary),p_user_id,p_request_id) returning id into visit;
  update public.file_assets set visit_memory_id=visit where id=any(p_photo_ids) and studio_id=p_studio_id;
  update public.appointments set status='completed',readiness_status='complete' where id=p_appointment_id and studio_id=p_studio_id;
  return (select jsonb_build_object('id',id,'clientId',client_id,'summary',summary,'createdAt',created_at) from public.visit_memories where id=visit);
end;
$$;
revoke all on function public.complete_studio_visit(uuid,uuid,uuid,uuid,uuid,text,uuid[]) from public,anon,authenticated;
grant execute on function public.complete_studio_visit(uuid,uuid,uuid,uuid,uuid,text,uuid[]) to service_role;

create or replace function public.register_intake_photo(p_link_id uuid,p_secret_hash text,p_photo_id uuid,p_kind text,p_object_path text,p_size bigint)
returns uuid language plpgsql security invoker set search_path='' as $$
declare session public.intake_sessions%rowtype; limit_count integer;
begin
  select * into session from public.intake_sessions where link_id=p_link_id and secret_hash=p_secret_hash for update;
  if not found or session.completed_at is not null or session.expires_at<=now()
    or not exists(select 1 from public.studio_intake_links where id=p_link_id and revoked_at is null)
    or not exists(select 1 from public.subscriptions where studio_id=session.studio_id and status in ('active','trialing') and current_period_end>now()) then raise exception 'Intake session unavailable'; end if;
  if p_kind not in ('inspiration','current') or p_kind is null or p_size is null or p_object_path is null or p_photo_id is null or p_size not between 1 and 2097152
    or p_object_path<>session.studio_id::text||'/'||session.id::text||'/'||p_kind||'/'||p_photo_id::text||'.webp' then raise exception 'Invalid photo'; end if;
  limit_count:=case p_kind when 'inspiration' then 3 else 2 end;
  if (select count(*) from public.file_assets where intake_session_id=session.id and kind=p_kind)>=limit_count then raise exception 'Photo limit reached'; end if;
  insert into public.file_assets(id,studio_id,intake_session_id,bucket,object_path,kind,mime_type,size_bytes)
  values(p_photo_id,session.studio_id,session.id,'client-experience-photos',p_object_path,p_kind,'image/webp',p_size);
  return p_photo_id;
end;
$$;
revoke all on function public.register_intake_photo(uuid,text,uuid,text,text,bigint) from public,anon,authenticated;
grant execute on function public.register_intake_photo(uuid,text,uuid,text,text,bigint) to service_role;

create or replace function public.register_visit_photo(p_studio_id uuid,p_user_id uuid,p_client_id uuid,p_request_id uuid,p_photo_id uuid,p_kind text,p_object_path text,p_size bigint)
returns uuid language plpgsql security invoker set search_path='' as $$
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_studio_id::text||p_request_id::text,0));
  if not exists(select 1 from public.studio_members where studio_id=p_studio_id and user_id=p_user_id)
    or not exists(select 1 from public.subscriptions where studio_id=p_studio_id and status in ('active','trialing') and current_period_end>now()) then raise exception 'Active Studio member required'; end if;
  if not exists(select 1 from public.clients where id=p_client_id and studio_id=p_studio_id) then raise exception 'Client unavailable'; end if;
  if exists(select 1 from public.visit_memories where studio_id=p_studio_id and request_id=p_request_id) then raise exception 'Visit already completed'; end if;
  if p_kind not in ('before','after') or p_kind is null or p_size is null or p_object_path is null or p_photo_id is null or p_size not between 1 and 2097152
    or p_object_path<>p_studio_id::text||'/visits/'||p_request_id::text||'/'||p_kind||'/'||p_photo_id::text||'.webp' then raise exception 'Invalid photo'; end if;
  if (select count(*) from public.file_assets where studio_id=p_studio_id and client_id=p_client_id and upload_request_id=p_request_id and kind=p_kind)>=5 then raise exception 'Photo limit reached'; end if;
  insert into public.file_assets(id,studio_id,client_id,upload_request_id,bucket,object_path,kind,mime_type,size_bytes,created_by)
  values(p_photo_id,p_studio_id,p_client_id,p_request_id,'client-experience-photos',p_object_path,p_kind,'image/webp',p_size,p_user_id);
  return p_photo_id;
end;
$$;
revoke all on function public.register_visit_photo(uuid,uuid,uuid,uuid,uuid,text,text,bigint) from public,anon,authenticated;
grant execute on function public.register_visit_photo(uuid,uuid,uuid,uuid,uuid,text,text,bigint) to service_role;

create or replace function public.create_client_appointment(p_studio_id uuid,p_first_name text,p_last_name text,p_service text,p_starts_at timestamptz)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare client uuid; appointment uuid; service uuid;
begin
 if not public.is_studio_member(p_studio_id) or not public.is_studio_subscription_active(p_studio_id) then raise exception 'Active Studio member required'; end if;
 if p_first_name is null or p_last_name is null or char_length(trim(p_first_name)) not between 2 and 50 or char_length(trim(p_last_name)) not between 2 and 50 or p_starts_at is null then raise exception 'Invalid client details'; end if;
 select id into service from public.services where studio_id=p_studio_id and category=p_service and active order by sort_order,id limit 1;
 if service is null then raise exception 'Active service required'; end if;
 insert into public.clients(studio_id,first_name,last_name) values(p_studio_id,trim(p_first_name),trim(p_last_name)) returning id into client;
 insert into public.appointments(studio_id,client_id,service_id,starts_at,status,readiness_status) values(p_studio_id,client,service,p_starts_at,'scheduled','draft') returning id into appointment;
 return jsonb_build_object('clientId',client,'appointmentId',appointment);
end;
$$;
revoke all on function public.create_client_appointment(uuid,text,text,text,timestamptz) from public,anon;
grant execute on function public.create_client_appointment(uuid,text,text,text,timestamptz) to authenticated;
-- Only the backend may inspect this aggregate readiness result.
create or replace function public.rovei_launch_schema_ready()
returns boolean language sql stable security invoker set search_path='' as $$
 select to_regprocedure('public.save_studio_configuration(uuid,text,text,text,text,text,jsonb,text[],jsonb,jsonb)') is not null
 and to_regprocedure('public.save_beauty_pack(uuid,uuid,text,text,text[])') is not null
 and to_regprocedure('public.is_studio_subscription_active(uuid)') is not null
 and to_regprocedure('public.submit_reusable_intake(uuid,text,text,text,text,timestamp with time zone,jsonb,text,uuid[])') is not null
 and (select count(*)>=8 from pg_catalog.pg_policies where schemaname='public' and policyname like '%active_members%')
 and exists(select 1 from storage.buckets where id='client-experience-photos' and not public)
 and not pg_catalog.has_table_privilege('authenticated','public.file_assets','INSERT,UPDATE,DELETE')
 and not exists(select 1 from pg_catalog.pg_proc where pronamespace='public'::regnamespace and proname in ('start_intake_session','submit_reusable_intake','complete_studio_visit','register_intake_photo','register_visit_photo') and (pg_catalog.has_function_privilege('anon',oid,'EXECUTE') or pg_catalog.has_function_privilege('authenticated',oid,'EXECUTE')));
$$;
revoke all on function public.rovei_launch_schema_ready() from public,anon,authenticated;
grant execute on function public.rovei_launch_schema_ready() to service_role;
commit;
