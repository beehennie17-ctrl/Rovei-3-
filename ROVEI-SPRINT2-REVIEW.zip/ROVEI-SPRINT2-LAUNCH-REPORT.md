# Rovei Engineering Sprint 2 — launch report

**Production decision: NO-GO for paying customers.** Substantial persistent-workflow code is complete and locally tested. The actual hosted schema is still missing required safeguards/RPCs, genuine Sandbox and hosted workflow tests have not run, and browser/production gates remain open.

Date: October 14, 2026, Africa/Johannesburg. Target: October 18 launch candidate, conditional on passing the remaining gates.

## Exact source and preservation

The workspace started from the supplied safe source archive plus the already delivered Sprint 1 patch. All 37 installed Sprint 1 output hashes matched pinned local snapshot `b5d8057ca7a385739c6b60cd6ca36a40765be966`. The archive SHA-256 remains `4d1da8cf3f161f8d73a47428391deca325f9ce4b015a74357bc0f9c2d269c5ba`. GitHub main was not substituted, and Sprint 1 was not applied twice.

All 15 protected reference/homepage/style/asset files remain byte-identical, including the approved HTML, homepage, global CSS and gallery assets. The runtime adapter changes functional state/events while reusing the approved markup. Source equality is verified; rendered pixel equivalence is still untested. The premium checkout component and its CSS were retained unchanged.

The original Codespace was not accessed or modified. No Git commit, push, merge, reset, force push, branch switch in that Codespace, hosted migration, deployment, live payment, real provider cancellation/refund or customer-data deletion occurred. Local review worktrees and an incremental checked patch were created. Generated Next environment declarations were restored to the installed baseline and excluded from the patch.

## Finished implementation and verification

| Area | Finished and actually tested | Limits / remaining proof |
|---|---|---|
| Reusable intake | Real `/intake/<uuid>` form route; owner-scoped persistent link; separate public browser namespace; cryptographic per-submission secret hashed in DB; atomic client/appointment/intake save; retry idempotency; required modules; fresh form without owner records | Actual hosted fresh-browser submission and owner restoration remain untested |
| Scheduling | Appointment creation/reschedule/cancellation APIs; server time-zone round-trip validation; duration/buffer/working-hours slot calculation; trigger guards all writers; conflicts roll back intake and manual client creation | Multi-process concurrent writers and hosted API success tests remain open; no new protected edit/reschedule controls added |
| Visits and history | Existing visit form saves to an atomic member/paid RPC; appointment completion and history stored together; request retries preserve exactly the same photos/summary; failed saves retain draft and READY status | Actual hosted completion and reopening on another device remain untested |
| Photos | Private server-derived paths; bounded multipart bodies; decoded real JPEG/PNG/WebP to metadata-stripped WebP; limits per step; staged metadata attached only to submitted IDs; stable upload IDs/retry; paid owner authorization and short-lived signed retrieval | Real Supabase upload/sign/download and negative browser-storage tests remain open; local photo tests are codec, SQL and API fixtures |
| Restoration | Reusable link restored; records refresh on home/clients/schedule and focus; appointment-specific intake responses; chronological packs choose the same latest template; visit dates use Studio timezone; local PostgreSQL records survive reopen | Hosted sessions/devices and production scale are unverified |
| Database security | Read-only hosted metadata inspection; exact support-schema/grant comparison; all migrations rehearsed; paid/unpaid/two-tenant/RPC/file-metadata safeguards tested locally | App-to-project reference not confirmed; hosted migrations/configuration and role/storage tests require approval |
| Hookdeck retries | Direct Paddle freshness retained; delayed path requires valid Paddle and Hookdeck HMACs over unchanged bytes; rotation header supported; tampered bodies, wrong keys, future/duplicate timestamps rejected | Actual Hookdeck signature/header/body passthrough and delayed delivery are untested |
| Operations | Fail-closed configuration/connectivity/schema health endpoint; boolean-only configuration verifier; deployment/HTTPS/SMTP/live-billing/monitoring/recovery runbook; exact migration review package | No production resources, SMTP, alerts, recovery exercise or live merchant setup verified |

Client name/email/notes PATCH and appointment-edit APIs compile, but their successful authenticated HTTP flows and protected UI exposure have not been tested. The approved shell currently represents one appointment per client; displaying/editing multiple bookings per returning client needs a separately approved interface decision. These gaps prevent declaring the Studio complete.

The existing per-appointment client-experience path now checks paid access, but its older multi-write progress/link/completion workflow still needs a concurrency/atomicity review and hosted test. The new reusable workflow has atomic SQL. Service/pricing editing, Studio event emails/reminders and complete operational notification delivery remain unfinished. Notification preferences persist but do not imply delivery.

## Test evidence

| Check | Result |
|---|---|
| Full automated suite | **95/95 PASS**, 31 more than installed Sprint 1; includes 23 local PostgreSQL checks, 10 approved-shell record bridge checks and 8 workflow/crypto/config checks |
| TypeScript | PASS, final source including both browser specifications |
| ESLint | PASS, zero errors and nine existing warnings |
| Standard production build | BLOCKED here: `uv_resident_set_memory` ENOENT from the sandbox |
| Diagnostic production build | PASS with a QA-only process-memory preload outside the source; compile, type checks and route generation completed |
| Compiled route checks | **13 assertions PASS**: original five plus health failure, four cross-origin record mutations, incomplete intake, oversized photo with/without Content-Length |
| Protected bytes | PASS, 15 files; full hashes included |
| Incremental installer | PASS on fresh installed-baseline worktree: 39 preimages, patch application, all output hashes, protected hashes, already-applied detection and refusal of changed preimages without writes |
| Browser/visual checks | BLOCKED: bundled Chromium exits SIGTRAP. Eight Playwright fixtures supplied, not reported passed. No desktop/mobile screenshot was captured or visually inspected |
| Genuine Paddle/Hookdeck tests | NOT RUN: no reachable authenticated integration preview/provider setup available |
| Hosted Supabase/Auth/Storage/email tests | NOT RUN: schema approval/target confirmation/test authorization pending |

Local PostgreSQL uses synthetic Auth/Storage catalogs. DOM/browser API fixtures are explicit. No fixture success is counted as a provider purchase, signed provider notification, real authentication, Storage transfer or hosted cross-device persistence. Initial test-harness mismatches, a compiled lazy-module loading issue and a lint naming error were corrected; no final automated failure remains.

Your reported standard Sprint 1 Codespaces build is accepted as prior evidence. Sprint 2 still needs a fresh unmodified Codespaces build; the diagnostic preload must not be installed in production.

## Phase and section progress

Percentages below mean passed checks in a declared verification checklist, not guessed feature completeness. Untested hosted implementations receive no release-gate credit.

| Phase | Verified result | Files | Blocker | Overall current-source gates |
|---|---|---|---|---:|
| Baseline | All 37 installed hashes; protected source preserved | No source writes | Exact original Codespace still outside this workspace | 1/12 |
| Persistent Studio batch | Local atomic intake/scheduling/visits/photos and interface failure/retry tests | Routes, backend helpers, records bridge, shell adapter, new SQL | Hosted schema/workflow approval | 2/12 after static checks |
| Security and retry rehearsal | Paid restrictions, tenant isolation, support reconciliation, RPC denial and dual signatures | SQL and tests; webhook verifier | Hosted role/storage and actual gateway evidence | 3/12 after local checks |
| Review delivery | 95 tests, diagnostic build, 13 handler checks, 15 protected hashes and checked 39-file installer | Exact manifest, logs, instructions and report | Standard build/browser/hosted/provider/production evidence | 3/12 |

| Section | Verified check coverage | Basis and remaining checks |
|---|---:|---|
| Studio persistence | **67% (8/12)** | Pack saves; Studio saves; restoration/reopen; reusable intake; scheduling; visits; photo encoding/attachment/retry; appointment-response association tested locally. Hosted device persistence, real Storage, complete editing/multiple-booking UI and notifications remain open |
| Database/tenant safeguards | **60% (6/10)** | Catalog/RLS audit and local migration/isolation/paid/RPC checks pass. Confirm target, reconcile/apply hosted schema, hosted role tests and hosted configuration hardening remain open |
| Billing | **50% (6/12)** | Local guard/reservation/signature/dedup/lifecycle/cancellation-retention checks pass. New retry crypto tests improve coverage; provider/hosted checks remain open |
| Checkout | **38% (3/8)** | Existing catalog arithmetic, tax/currency parsing and compilation retained. Provider fields/methods/taxes and browser/visual flows remain open |
| Browser/visual verification | **0% (0/2)** | Working-browser execution and rendered approved-baseline comparison are both blocked; source hashes and DOM tests do not substitute |
| Authentication | **33% (2/6)** | Existing confirmation/redirect unit checks retained. Hosted signup/email/recovery/returning-session/account checks remain open |
| Production readiness | **20% (1/5)** | Existing CI/reset safeguards retained. New health/config checks and runbook are tested/prepared locally, but hosting, SMTP, operations/recovery and approved live billing remain open |

**Current-source customer-ready verification: 25% (3/12 fully verified gates).** Sprint 1's standard build was user-confirmed, so the prior installed source had a fourth gate. It is pending again for this incremental source until the unmodified Sprint 2 build runs in Codespaces. This is a verification requirement, not a claimed product regression.

## All twelve launch gates

| # | Gate | Status / evidence needed |
|---:|---|---|
| 1 | Exact source and protected design preservation | PASS: installed hashes, protected bytes and incremental integration checks |
| 2 | Static checks | PASS: final TypeScript and ESLint |
| 3 | Automated local SQL/DOM/compiled-handler checks | PASS: 95 tests and 13 handler assertions |
| 4 | Standard production build | OPEN for Sprint 2; Sprint 1 user-confirmed, latest diagnostic build passes |
| 5 | Real browser and visual regression | BLOCKED by Chromium; run eight fixtures and compare approved desktop/mobile views |
| 6 | Hosted signup/confirmation/recovery/returning login | OPEN; delivered email and actual session evidence required |
| 7 | Genuine monthly/annual Paddle Sandbox checkout | OPEN; actual price objects, fields/tax/currency/methods and completed purchases required |
| 8 | Signed Hookdeck delivery and hosted subscription sync | OPEN; genuine forwarded payload, delayed retry, duplicate/order and correct mapping required |
| 9 | Hosted activation, failure, recovery and double-confirm cancellation | OPEN; disposable Sandbox subscription tests and retained records required |
| 10 | Complete hosted Studio persistence | OPEN; actual intake/booking/visits/photos/device restoration and remaining editing/notification gaps |
| 11 | Hosted two-tenant, unpaid and private-storage isolation | OPEN; approved test owners and real direct/Storage negative tests required |
| 12 | Production/live/email/operations readiness | OPEN; host/domain/SMTP/monitoring/backups/restoration and explicit live/deployment approvals |

## Consolidated next approvals and launch blockers

1. Confirm the running app's nonsecret Supabase project reference. The healthy connected candidate is Rovei-3-, `errzsgncbygxwwmwndha`; no target was assumed for writes.
2. Review `HOSTED-MIGRATION-REVIEW.md` and its five exact SQL files, confirm a private backup/recovery route, then explicitly approve hosted application and deliberate migration-history reconciliation. Local rehearsal is complete; disposable hosted rehearsal remains desirable before shared rollout.
3. Provide the reachable Codespaces review URL and authorize synthetic test owners/clients plus real Sandbox monthly/annual purchases and test-subscription cancellation. Keep keys in private configuration and authenticate through the connected session/handoff, not by pasting secrets into chat. Configure the Hookdeck signing secret privately.
4. Approve a narrowly scoped interface proposal before adding missing client edit/reschedule/multiple-booking controls or resolving protected prototype/disclosure wording. No such protected change is included here.
5. Choose the production host/domain and SMTP provider, then complete hosted email, monitoring, backup/restore and onboarding rehearsals. Production deployment and live billing remain separate approvals after all critical tests pass.

Already issued private photo URLs can remain valid for up to five minutes after access revocation. Abandoned staged uploads have no automatic deletion policy; choose retention/cleanup explicitly. The current media endpoint has a 500-photo response limit, and the single-studio scheduling model supports one concurrent appointment. These operational/product constraints need verification and owner review before onboarding customers at scale.

## Exact changed-file manifest

- `app/api/appointments/[id]/route.ts`
- `app/api/appointments/route.ts`
- `app/api/clients/[id]/route.ts`
- `app/api/clients/route.ts`
- `app/api/health/route.ts`
- `app/api/public/intake/[linkId]/photos/route.ts`
- `app/api/public/intake/[linkId]/session/route.ts`
- `app/api/public/intake/[linkId]/slots/route.ts`
- `app/api/public/intake/[linkId]/submit/route.ts`
- `app/api/studio/intake-link/route.ts`
- `app/api/studio/media/route.ts`
- `app/api/studio/records/route.ts`
- `app/api/visits/photos/route.ts`
- `app/api/visits/route.ts`
- `app/api/webhooks/paddle/route.ts`
- `app/intake/[linkId]/route.ts`
- `app/route.ts`
- `docs/LAUNCH_RUNBOOK.md`
- `lib/auth/locked-shell.ts`
- `lib/backend/appointment-workflows.ts`
- `lib/backend/errors.ts`
- `lib/backend/intake-workflows.ts`
- `lib/backend/locked-studio-state.ts`
- `lib/backend/public-client-experience.ts`
- `lib/backend/record-photos.ts`
- `lib/backend/scheduling.ts`
- `lib/backend/workflow-schemas.ts`
- `lib/billing/webhook-verification.ts`
- `lib/photos/image-codec.ts`
- `public/rovei-records-bridge.js`
- `scripts/verify-launch-config.mjs`
- `supabase/migrations/20261014182409_persistent_studio_workflows.sql`
- `tests/database-integration.test.mjs`
- `tests/e2e/checkout.spec.ts`
- `tests/e2e/records.spec.ts`
- `tests/locked-studio-state.test.mjs`
- `tests/records-bridge.test.mjs`
- `tests/route-smoke.mjs`
- `tests/workflow-core.test.mjs`

The ZIP includes `rovei-sprint2.patch`, before/after SHA-256 manifest, installed Sprint 1 baseline hashes, protected hashes, private-backup/check/apply helper, migration approval package and test logs. It contains no environment files, credentials, private customer data or QA process-memory preload.

## Official implementation references

- Hookdeck destination signatures and raw-body passthrough: https://hookdeck.com/docs/use-cases/ai-agents/how-to-verify-incoming-webhooks
- Paddle signature verification: https://developer.paddle.com/webhooks/about/signature-verification/
- Supabase RLS: https://supabase.com/docs/guides/database/postgres/row-level-security
- Private Storage downloads: https://supabase.com/docs/guides/storage/serving/downloads
- Authentication SMTP and production configuration: https://supabase.com/docs/guides/auth/auth-smtp and https://supabase.com/docs/guides/deployment/going-into-prod
- Paddle go-live checklist: https://developer.paddle.com/build/go-live-checklist/

These references informed the code/runbook; they do not provide evidence that this Rovei deployment has passed the provider or production gates.
